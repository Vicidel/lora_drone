

 void centerString(char *string );
 
 void splashScreen();
 void displayTemp(float temp, String text );
 void displayLoraWanParams(String DevEUI, String AppEUI, String AppKey );
 void displayLoraTX(bool status);
 void displayLoraRX(bool status);
 void displayTime2TX(long int time_ms);
 void displayLora( );

